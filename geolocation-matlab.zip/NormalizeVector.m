function vNormalized = NormalizeVector( v )

vNormalized = v / norm( v );

end
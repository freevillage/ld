function ColormapGray

NewColormap = [ gray', ( 1 - gray )' ]';
colormap( NewColormap );
CenterCAxis( 1 );

end
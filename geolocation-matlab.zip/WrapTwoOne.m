function y = WrapTwoOne( x )

y = wrapToPi( pi*x ) / pi;

end
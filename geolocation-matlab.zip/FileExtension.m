function extension = FileExtension( filename )

[~,~,extension] = fileparts( filename );

end
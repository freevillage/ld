function flag = IsConstantArray( array )

flag = all( array == array(1) );

end
function Result = IsEven( Data )

Result = ~IsOdd( Data );

end
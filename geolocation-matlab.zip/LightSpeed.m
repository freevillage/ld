function c = LightSpeed

c = 299792458; % m/s

end
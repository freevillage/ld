function antisymmetric = AntisymmetricPart( matrix )

[~,antisymmetric] = SymmetricPart( matrix );

end
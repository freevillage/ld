function randomColor = RandomRGBColor

assert( nargin == 0 );

randomColor = rand( 1, 3 );

end
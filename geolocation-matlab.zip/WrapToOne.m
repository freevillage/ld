function y = WrapToOne( x )

y = wrapToPi( pi*x ) / pi;

end
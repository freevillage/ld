function PrintLandscape( filename, varargin )

orient landscape;
PrintFigure( filename, varargin{:} );

end
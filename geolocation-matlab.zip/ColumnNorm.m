function norm = ColumnNorm( matrix )

norm = sqrt( sum( abs( matrix .^ 2 )  ) );

end
function tf = IsNumericScalar( input )

tf = isscalar( input ) && isnumeric( input );

end
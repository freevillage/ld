function y = First( x )

y = x(1);

end
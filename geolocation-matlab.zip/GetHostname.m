function hostname = GetHostname

[~,hostname] = system( 'hostname' );

end
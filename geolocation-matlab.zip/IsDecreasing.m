function yesno = IsDecreasing( array )

yesno = IsIncreasing( -array );

end
function y = RandomInteger( maxInteger, size )

y = ceil( maxInteger * rand( size ) );

end
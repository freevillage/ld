function yesno = IsNumericVector( input )

yesno = isnumeric( input ) && isvector( input );

end